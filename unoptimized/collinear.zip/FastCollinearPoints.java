/*-------------------------------------------------
 * Assignment: Same line segment (fast) test.
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/
//import edu.princeton.cs.algs4.Quick;
import java.util.Arrays;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class FastCollinearPoints {
  private Point m_points[];
  private Point m_origin;
  private LineSegment[] enlargeArray(LineSegment[] arr)
  {
    int nNewSize = 2*arr.length;
    LineSegment[] newArr = new LineSegment[nNewSize];
    for (int i = 0; i < arr.length; i++)
      newArr[i] = arr[i];
    return newArr;
  }
  private Point[] copyPoints(Point[] in, int nStart, int nEnd)
  {
    Point[] out = new Point[nEnd - nStart];
    int j = 0;
    for(int i = nStart; i < nEnd; i++)
      out[j++] = in[i];
    return out;
  }
  // finds all line segments containing 4 or more points
  public FastCollinearPoints(Point[] points)
  {
    if ( null == points ) throw 
      new java.lang.NullPointerException("null argument(points array)");
    for (Point p : points)
    {
      if (null == p) throw 
        new java.lang.NullPointerException("null element in points array");
    }
    /*
    StdOut.println("Input(unsorted): ");
    for (Point p : points)
      StdOut.print(p);
    StdOut.println("");
    */
    //Quick.sort(points);//ascending order
    m_points = copyPoints(points, 0, points.length);
    Arrays.sort(m_points);
    for(int i = 1; i < m_points.length; i++)
    {
      if (0 == m_points[i-1].compareTo(m_points[i])) throw
        new java.lang.IllegalArgumentException("points equal");
    }
    /*
    StdOut.println("Input(natural ordered): ");
    for (Point p : points)
      StdOut.print(p);
    StdOut.println("");
    */
  }
  public int numberOfSegments()   // the number of line segments
  {
    LineSegment[] s = segments();
    if (null == s)
      return 0;
    int nCount = 0;
    while(nCount< s.length && null != s[nCount])
      nCount++;
    return nCount;
  }
  public LineSegment[] segments() // the line segments
  {
    int nCurrentSize = 5, nNeededSize = 0;
    LineSegment[] segments = new LineSegment[nCurrentSize];

    int nOnlyOnce = 0;
    for (int i = 0; i < m_points.length; i++)
    {
      Point origin = m_points[i];
      Point[] tmp = copyPoints(m_points, i+1, m_points.length);
      Arrays.sort(tmp, origin.slopeOrder());
      /*
      StdOut.println("Sorted by origin: " + origin);
      for (int j = 0; j < tmp.length; j++)
      {
        StdOut.print(tmp[j]);
        StdOut.print(" slope : ");
        StdOut.print(origin.slopeTo(tmp[j]));
        StdOut.print(" ");
      }
      StdOut.println("");
      */
      LineSegment ls = null;
      int nEqualCount = 0;
      for (int j = 0; j < tmp.length-1; j++)
      {
        if (origin.slopeTo(tmp[j]) == 
            origin.slopeTo(tmp[j+1]))
          nEqualCount++;
        else if (0 != nEqualCount)
        {
          Point low = origin;
          for (int k = tmp.length-1; k > 1; k--)
          {
            if (origin.slopeTo(tmp[k]) == 
                origin.slopeTo(tmp[k-1]))
            {
              low = tmp[k-1];
              nEqualCount++;
            }
            else
              break;
          }
          if (nEqualCount >= 2)
          {
//StdOut.println("found equal slope between: " + (j-nEqualCount) + " and " + j);
            ls = new LineSegment(low, tmp[j]);
            nOnlyOnce = 1;
          }
          nEqualCount = 0;
        }
      }
      if (0 == nOnlyOnce && nEqualCount >= 2)
      {
//StdOut.println("found equal slope between: " + (j-nEqualCount) + " and " + j);
        ls = new LineSegment(origin, tmp[tmp.length-1]);
        nEqualCount = 0;
        nOnlyOnce = 1;
      }
      if (null != ls)
        segments[nNeededSize++] = ls;
      if (nNeededSize >= nCurrentSize)
      {
        segments = enlargeArray(segments);
        nCurrentSize = segments.length;
      }
    }
    if (0 == segments.length)
      return null;
    int nRetCount = 0;
    while (null != segments[nRetCount])
      nRetCount++;
    LineSegment[] ret = new LineSegment[nRetCount];
    int j = 0;
    for(int i = 0; i < nRetCount; i++)
      ret[j++] = segments[i];
    return ret;
  }
  public static void main(String[] args) {
    // read the N points from a file
    In in = new In(args[0]);
    int N = in.readInt();
    Point[] points = new Point[N];
    for (int i = 0; i < N; i++) {
        int x = in.readInt();
        int y = in.readInt();
        points[i] = new Point(x, y);
    }

    // draw the points
    StdDraw.show(0);
    StdDraw.setXscale(0, 32768);
    StdDraw.setYscale(0, 32768);
    for (Point p : points) {
        p.draw();
    }
    StdDraw.show();

    // print and draw the line segments
    FastCollinearPoints collinear = new FastCollinearPoints(points);
    for (LineSegment segment : collinear.segments()) {
      if (null == segment)
        break;
        StdOut.println(segment);
        segment.draw();
    }
  }
}