/*-------------------------------------------------
 * Assignment 1: Percolation via Monte Carlo sim.
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdOut;

public class PercolationStats {
   private double[] mDFractions;
   private double mDMean = 0;
   private double mDStdDev = 0;
   // perform T independent experiments on an N-by-N grid
   public PercolationStats(int N, int T)
   {
     if (N <= 0) throw 
       new IllegalArgumentException("Grid size " + N + " is 0 or negative");
     if (T <= 0) throw 
       new IllegalArgumentException("Test number " + T + " is 0 or negative");
     mDFractions = new double[T];
     int nCrtT = T-1;
     while (0 <= nCrtT)
     {
       Percolation p = new Percolation(N);
       int nNumerator = 0;
       while (!p.percolates())
       {
         int i = StdRandom.uniform(1, N+1);
         int j = StdRandom.uniform(1, N+1);
         //StdOut.println("Checking row: " + i + " column: " + j + "...");
         if (p.isOpen(i, j))
         {
           //StdOut.println("Already open row: " + i + " column: " + j + "...");
           continue;
         }
         p.open(i, j);
         nNumerator++;
         //StdOut.println("Numerator: " + nNumerator + "...");
         //StdOut.println("next ...");
       }
       double nDenominator = N*N;
       mDFractions[nCrtT] = nNumerator/nDenominator;
       nCrtT--;
     }
   }
   public double mean()// sample mean of percolation threshold
   {
     if (0 != mDMean)
       return mDMean;
     mDMean = StdStats.mean(mDFractions);
     return mDMean;
   }
   public double stddev()// sample standard deviation of percolation threshold
   {
     if (0 != mDStdDev)
       return mDStdDev;
     mDStdDev = StdStats.stddev(mDFractions);
     return mDStdDev;
   }
   public double confidenceLo()// low  endpoint of 95% confidence interval
   {
     if (0 == mDStdDev)
       stddev();
     return mDMean - 1.96*mDStdDev/Math.sqrt(mDFractions.length);
   }
   public double confidenceHi()// high endpoint of 95% confidence interval
   {
     if (0 == mDStdDev)
       stddev();
     return mDMean + 1.96*mDStdDev/Math.sqrt(mDFractions.length);
   }

   public static void main(String[] args)    // test client (described below)
   {
     int N = Integer.parseInt(args[0]), T = Integer.parseInt(args[1]);
     StdRandom.setSeed(System.currentTimeMillis());
     PercolationStats ps = new PercolationStats(N, T);
     
     StdOut.println("mean\t\t\t=" + ps.mean());
     StdOut.println("std. dev.\t\t\t=" + ps.stddev());
     StdOut.println("95% confidence interval =" + ps.confidenceLo() + 
                        ", " + ps.confidenceHi());
   }
}