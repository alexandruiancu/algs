/*-------------------------------------------------
 * Assignment 1: Percolation via Monte Carlo sim.
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
   private int mN = 0;
   private WeightedQuickUnionUF mWQU;
   private boolean[] mGrid;
   public Percolation(int N)// create N-by-N grid, with all sites blocked
   {
     mN = N;
     mGrid = new boolean[mN*mN+2];
     //open virtual ends
     mGrid[mN*mN] = true;
     mGrid[mN*mN+1] = true;
     mWQU = new WeightedQuickUnionUF(mN*mN+2/*vTop & vBottom*/);
   }
   // open site (row i, column j) if it is not open already
   public void open(int i, int j)
   {
     checkBounds(i, j);
     mGrid[mN*(i-1)+(j-1)] = true;
     if ((i-1) > 0/* 1 based index */ && mGrid[mN*((i-1)-1)+(j-1)])
       mWQU.union(mN*((i-1)-1)+(j-1), mN*(i-1)+(j-1)); //up
     if ((j-1) > 0/* 1 based index */ && mGrid[mN*(i-1)+(j-1)-1])
       mWQU.union(mN*(i-1)+(j-1)-1, mN*(i-1)+(j-1)); //left
     if (j < mN && mGrid[mN*(i-1)+j])
       mWQU.union(mN*(i-1)+(j-1), mN*(i-1)+j); //right
     if (i < mN && mGrid[mN*(i-1)+(j-1)])
       mWQU.union(mN*(i-1)+(j-1), mN*(i)+(j-1)); //bottom
     if (i == 1)
       mWQU.union(mN*mN, mN*(i-1)+(j-1)); //v top
     if (i == mN)
       mWQU.union(mN*(i-1)+(j-1), mN*mN+1); //v bottom
   }
   public boolean isOpen(int i, int j)     // is site (row i, column j) open?
   {
     checkBounds(i, j);
     return isOpenNotChecked(i, j);
   }
   public boolean isFull(int i, int j)     // is site (row i, column j) full?
   {
     return !isOpen(i, j);
   }
   public boolean percolates()             // does the system percolate?
   {
     // v top and bottom conn
     return mWQU.connected(mN*mN, mN*mN+1);
   }
   public static void main(String[] args)  // test client (optional)
   {
   }
   ////////////////////////////////////////////////////////////////////////////
   // implementation
   private void checkBounds(int i, int j)
   {
     if (i < 1 || i > mN) throw 
       new IndexOutOfBoundsException("row index " + i + " out of bounds("
                                       + mN + ")");
     if (j < 1 || j > mN) throw 
       new IndexOutOfBoundsException("column index " + j + " out of bounds(" 
                                       + mN + ")");
   }
   // i and j represent indexes not row/column as usual
   private boolean isOpenNotChecked(int i, int j)
   {
     return mGrid[mN*(i-1)+(j-1)];
   }
}