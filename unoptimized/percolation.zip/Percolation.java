/*-------------------------------------------------
 * Assignment 1: Percolation via Monte Carlo sim.
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
   private int mN = 0;
   private WeightedQuickUnionUF mWQUT, mWQUB;
   private boolean[] mGrid;
   public Percolation(int N)// create N-by-N grid, with all sites blocked
   {
     if (N <= 0) throw 
       new IllegalArgumentException("Grid size " + N + " is 0 or negative");
     mN = N;
     mGrid = new boolean[mN*mN+2];
     //open virtual ends
     mGrid[mN*mN] = true;
     mGrid[mN*mN+1] = true;
     mWQUT = new WeightedQuickUnionUF(mN*mN+2/*v top, v bottom*/);
     mWQUB = new WeightedQuickUnionUF(mN*mN+2/*v top, v bottom*/);
   }
   // open site (row i, column j) if it is not open already
   public void open(int i, int j)
   {
     checkBounds(i, j);
     mGrid[mN*(i-1)+(j-1)] = true;
     if ((i-1) > 0/* 1 based index */ && mGrid[mN*((i-1)-1)+(j-1)])
     {
       mWQUT.union(mN*((i-1)-1)+(j-1), mN*(i-1)+(j-1)); //up
       mWQUB.union(mN*((i-1)-1)+(j-1), mN*(i-1)+(j-1)); //up
     }
     if ((j-1) > 0/* 1 based index */ && mGrid[mN*(i-1)+(j-1)-1])
     {
       mWQUT.union(mN*(i-1)+(j-1)-1, mN*(i-1)+(j-1)); //left
       mWQUB.union(mN*(i-1)+(j-1)-1, mN*(i-1)+(j-1)); //left
     }
     if (j < mN && mGrid[mN*(i-1)+j])
     {
       mWQUT.union(mN*(i-1)+(j-1), mN*(i-1)+j); //right
       mWQUB.union(mN*(i-1)+(j-1), mN*(i-1)+j); //right
     }
     if (i < mN && mGrid[mN*i+(j-1)])
     {
       mWQUT.union(mN*(i-1)+(j-1), mN*i+(j-1)); //bottom
       mWQUB.union(mN*(i-1)+(j-1), mN*i+(j-1)); //bottom
     }
     if (i == 1)
       mWQUT.union(mN*mN, mN*(i-1)+(j-1)); //v top
     if (i == mN)
       mWQUB.union(mN*(i-1)+(j-1), mN*mN+1); //v bottom
     if (mWQUB.connected(mN*(i-1)+(j-1), mN*mN+1))
       mWQUT.union(mN*(i-1)+(j-1), mN*mN+1);
     if (mWQUT.connected(mN*mN, mN*(i-1)+(j-1)))
       mWQUB.union(mN*mN, mN*(i-1)+(j-1));
   }
   public boolean isOpen(int i, int j)     // is site (row i, column j) open?
   {
     checkBounds(i, j);
     return isOpenNotChecked(i, j);
   }
   public boolean isFull(int i, int j)     // is site (row i, column j) full?
   {
     if (!isOpen(i, j))
       return false;
     return mWQUT.connected(mN*(i-1)+(j-1), mN*mN); /*|| 
       mWQUB.connected(mN*(i-1)+(j-1), mN*mN+1);*/
   }
   public boolean percolates()             // does the system percolate?
   {
     // v top and bottom conn
     return mWQUT.connected(mN*mN, mN*mN+1) || mWQUB.connected(mN*mN, mN*mN+1);
   }
   public static void main(String[] args)  // test client (optional)
   {
   }
   ////////////////////////////////////////////////////////////////////////////
   // implementation
   private void checkBounds(int i, int j)
   {
     if (i < 1 || i > mN) throw 
       new IndexOutOfBoundsException("row index " + i + " out of bounds("
                                       + mN + ")");
     if (j < 1 || j > mN) throw 
       new IndexOutOfBoundsException("column index " + j + " out of bounds(" 
                                       + mN + ")");
   }
   // i and j represent indexes not row/column as usual
   private boolean isOpenNotChecked(int i, int j)
   {
     return mGrid[mN*(i-1)+(j-1)];
   }
}