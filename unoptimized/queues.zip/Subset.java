/*-------------------------------------------------
 * Assignment 1: Dequeue
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class Subset {
  public static void main(String[] args)
  {
    if (args.length < 1)
      return;
    int k = Integer.parseInt(args[0]);
    RandomizedQueue<String> rq = new RandomizedQueue<String>();
    String[] inArray = null;
    if (args.length > 1)
    {
      inArray = new String[args.length-1];
      for (int i = 1; i < args.length; i++)
        inArray[i-1] = args[i];
    }
    else
      inArray = StdIn.readAllStrings();
    for (String s : inArray)
      rq.enqueue(s);

    StdRandom.setSeed(System.currentTimeMillis());
    int nCount = 0;
    for (String s : rq)
    {
      if (nCount++ >= k)
        break;
      StdOut.println(s);
    }
  }
}

