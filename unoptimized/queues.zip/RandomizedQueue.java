/*-------------------------------------------------
 * Assignment 1: Randomized Queue
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/
import edu.princeton.cs.algs4.StdRandom;
import java.util.Iterator;
import edu.princeton.cs.algs4.StdOut;

public class RandomizedQueue<Item> implements Iterable<Item> {
  private Item[] mItems = null;
  private int mHead, mTail;
  private class RandomizedQueueIterator implements Iterator<Item>
  {
    public Item[] mItems = null;
    private int nCrtIndex = mHead;
    public boolean hasNext()
    {
      return (!isEmpty() && nCrtIndex <= mTail);
    }
    public Item next()
    {
      //StdOut.println((Object)mItems);
      //StdOut.println(nCrtIndex);
      if (nCrtIndex <= mTail)
        return mItems[nCrtIndex++];
      throw new java.util.NoSuchElementException("no more elements");
    }
    public void remove()
    {
      throw new java.lang.UnsupportedOperationException();
    }
  }
  public RandomizedQueue()// construct an empty randomized queue
  {
    mItems = (Item[]) new Object[2];
    mHead = -1;
    mTail = -1;
  }
  public boolean isEmpty()// is the queue empty?
  {
    return 0 == size();
  }
  public int size()       // return the number of items on the queue
  {
    if (-1 == mTail || -1 == mHead)
      return 0;
    if (mTail == mHead)
      return 1;
    return mTail-mHead+1;
  }
  public void enqueue(Item item)// add the item
  {
    if (null == item)
      throw new java.lang.NullPointerException("will not add null element!");
    if (mTail >= mItems.length-1)
      increaseSize();
    mItems[++mTail] = item;
    if (0 > mHead)
      mHead = 0;
//    {
//      StdOut.println("after enqueue");
//      for(int i=0;i<mItems.length;i++)
//      {
//        StdOut.println("Item(#" + i + "): " + mItems[i]);
//      }
//    }
  }
  public Item dequeue()   // remove and return a random item
  {
    if (isEmpty()) throw new java.util.NoSuchElementException("empty queue");

    Item i = mItems[mHead++];
    if (size() <= mItems.length/4)
      decreaseSize();
    return i;
  }
  public Item sample()    // return (but do not remove) a random item
  {
    if (isEmpty()) throw new java.util.NoSuchElementException("empty queue");
    return mItems[mHead];
  }
  // return an independent iterator over items in random order
  public Iterator<Item> iterator()
  {
    RandomizedQueueIterator rqi = new RandomizedQueueIterator();
    rqi.mItems = (Item[]) new Object[size()];
    for (int i = 0; i < rqi.mItems.length; i++)
      rqi.mItems[i] = mItems[mHead+i];
    suffle(rqi.mItems);
    return rqi;
  }
  public static void main(String[] args)// unit testing
  {
    RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
    StdOut.println("Size: " + rq.size());
  }
  /////////////////////////////////////////////////////////////////////////////
  //implementation
  private void increaseSize()
  {
    Item[] newItems = (Item[]) new Object[2*mItems.length];
    replaceItems(newItems);
  }
  private void decreaseSize()
  {
    if (isEmpty())
      return;
    Item[] newItems = (Item[]) new Object[mItems.length/2];
    replaceItems(newItems);
  }
  private void replaceItems(Item[] to)
  {
//    {
//      StdOut.println("before replace items");
//      for(int i=0;i<mItems.length;i++)
//      {
//        StdOut.println("Item(#" + i + "): " + mItems[i]);
//      }
//    }
    int nToCount = 0;
    for (int nFromCount = mHead; nFromCount <= mTail; nFromCount++)
      to[nToCount++] = mItems[nFromCount];
    mTail -= mHead;
    mHead = 0;
    mItems = to;
//    {
//      StdOut.println("after replace items");
//      for(int i=0;i<mItems.length;i++)
//      {
//        StdOut.println("Item(#" + i + "): " + mItems[i]);
//      }
//    }
  }
  private void swap(Item[] arr, int i, int j)
  {
    if (0 <= i && i <= arr.length &&
        0 <= j && j <= arr.length)
    {
      Item tmp = arr[j];
      arr[j] = arr[i];
      arr[i] = tmp;
    }
  }
  private void suffle(Item[] arr)
  {
    if (0 == arr.length)
      return;
    for (int i = 1; i < arr.length; i++)
    {
      int nRand = StdRandom.uniform(0, i+1);
      if (i != nRand)
        swap(arr, i, nRand);
    }
  }
}
