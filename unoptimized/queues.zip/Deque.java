/*-------------------------------------------------
 * Assignment 1: Dequeue
 * AUTHOR: Alexandru IANCU
 *------------------------------------------------*/

import java.util.Iterator;
import edu.princeton.cs.algs4.StdOut;

public class Deque<Item> implements Iterable<Item> {
  private class Node
  {
    Item item;
    Node prev;
    Node next;
  }
  private class DequeIterator implements Iterator<Item>
  {
    private Node crt = mFront;
    public boolean hasNext()
    {
      return null != crt;
    }
    public Item next()
    {
      if (null == crt) throw
        new java.util.NoSuchElementException();
      Item item = crt.item;
      crt = crt.next;
      return item;
    }
    public void remove()
    {
      throw new java.lang.UnsupportedOperationException();
    }
  }
  private Node mFront = null, mBack = null;
  public Deque()// construct an empty deque
  {
    mFront = null;
    mBack = null;
  }
  public boolean isEmpty()// is the deque empty?
  {
    return null == mFront || null == mBack;
  }
  public int size()// return the number of items on the deque
  {
    int nCount = 0;
    Node crt = mFront;
    while (null != crt)
    {
      nCount++;
      crt = crt.next;
    }
    return nCount;
  }
  public void addFirst(Item item)// add the item to the front
  {
    checkNullItem(item);
    Node newFront = new Node();
    newFront.item = item;
    if (!isEmpty())
    {
      mFront.prev = newFront;
      newFront.next = mFront;
    }
    mFront = newFront;
    if (null == mBack)
      mBack = mFront;
  }
  public void addLast(Item item)// add the item to the end
  {
    checkNullItem(item);
    Node newBack = new Node();
    newBack.item = item;
    if (!isEmpty())
    {
      mBack.next = newBack;
      newBack.prev = mBack;
    }
    mBack = newBack;
    if (null == mFront)
      mFront = mBack;
  }
  public Item removeFirst()// remove and return the item from the front
  {
    checkMissingItem();
    Node crt = mFront;
    mFront = mFront.next;
    if (null != mFront)
      mFront.prev = null;
    else
      mBack = mFront;
    return crt.item;
  }
  public Item removeLast()// remove and return the item from the end
  {
    checkMissingItem();
    Node crt = mBack;
    mBack = mBack.prev;
    if (null != mBack)
      mBack.next = null;
    else
      mFront = mBack;
    return crt.item;
  }
  // return an iterator over items in order from front to end
  public Iterator<Item> iterator()
  {
    return new DequeIterator();
  }
  public static void main(String[] args)   // unit testing
  {
    //Deque<Integer> dq = new Deque<Integer>();
    //dq.addFirst(0);
    //dq.removeLast();
    //dq.addFirst(2);
    //dq.addFirst(3);
    //dq.isEmpty();
    //dq.removeFirst();
    //dq.removeLast();
    //StdOut.println("is empty: " + dq.isEmpty());
    //dq.addLast(7);
    //dq.isEmpty();
    //StdOut.println("Size: " + dq.size());
    //dq.addLast(7);
    //dq.addLast(3);
    //StdOut.println("Size: " + dq.size());
    //StdOut.println("removeLast: " + dq.removeLast());
    //StdOut.println("removeFirst: " + dq.removeFirst());
    //for(Integer i : dq)
    //  StdOut.println("Iterating: " + i);
  }
  ////////////////////////////////////////////////////////////////////////////
  // implementation
  private void checkNullItem(Item item)
  {
    if (null == item) throw 
      new java.lang.NullPointerException("null item");
  }
  private void checkMissingItem()
  {
    if (isEmpty()) throw 
      new java.util.NoSuchElementException("missing item");
  }
}
